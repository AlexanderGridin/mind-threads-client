import { NoteView } from '@/components/note/NoteView'

interface NotePageProps {
  params: Promise<{ id: string }>
}

export default async function NotePage({ params }: NotePageProps) {
  const { id } = await params
  return <NoteView noteId={id} />
}
