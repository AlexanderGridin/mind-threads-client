'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { FileText, LayoutGrid, List, Plus, X } from 'lucide-react'
import { useNotes } from '@/components/providers/NotesProvider'
import { ThemeToggle } from '@/components/ui/ThemeToggle'
import { SearchInput } from '@/components/ui/SearchInput'
import { NoteCard } from './NoteCard'

type Layout = 'grid' | 'list'

export function Dashboard() {
  const router = useRouter()
  const { notes, createNote } = useNotes()
  const [search, setSearch] = useState('')
  const [showCreate, setShowCreate] = useState(false)
  const [newTitle, setNewTitle] = useState('')
  const [layout, setLayout] = useState<Layout>('grid')
  const createInputRef = useRef<HTMLInputElement>(null)

  // Persist layout preference
  useEffect(() => {
    const saved = localStorage.getItem('nordnote-layout') as Layout | null
    if (saved === 'grid' || saved === 'list') setLayout(saved)
  }, [])

  const toggleLayout = useCallback(() => {
    setLayout((prev) => {
      const next: Layout = prev === 'grid' ? 'list' : 'grid'
      localStorage.setItem('nordnote-layout', next)
      return next
    })
  }, [])

  const filtered = useMemo(
    () =>
      notes.filter((n) =>
        n.title.toLowerCase().includes(search.toLowerCase())
      ),
    [notes, search]
  )

  const openCreateForm = useCallback(() => {
    setNewTitle('')
    setShowCreate(true)
    setTimeout(() => createInputRef.current?.focus(), 0)
  }, [])

  const handleCreate = useCallback(() => {
    const title = newTitle.trim()
    if (!title) return
    const note = createNote(title)
    setShowCreate(false)
    setNewTitle('')
    router.push(`/note/${note.id}`)
  }, [newTitle, createNote, router])

  const cancelCreate = useCallback(() => {
    setShowCreate(false)
    setNewTitle('')
  }, [])

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-border bg-background/95 px-6 py-4 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <FileText className="h-4 w-4" />
          </div>
          <div>
            <h1 className="text-base font-semibold text-foreground leading-none">
              NordNote
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {notes.length} {notes.length === 1 ? 'notebook' : 'notebooks'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search notebooks…"
            className="w-48 sm:w-64"
          />
          <button
            onClick={toggleLayout}
            aria-label={layout === 'grid' ? 'Switch to list view' : 'Switch to grid view'}
            className="rounded-lg border border-border p-1.5 text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
          >
            {layout === 'grid' ? (
              <List className="h-4 w-4" />
            ) : (
              <LayoutGrid className="h-4 w-4" />
            )}
          </button>
          <ThemeToggle />
          <button
            onClick={openCreateForm}
            className="flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">New Note</span>
          </button>
        </div>
      </header>

      {/* Create note inline form */}
      {showCreate && (
        <div className="border-b border-border bg-card px-6 py-3">
          <div className="mx-auto flex max-w-sm items-center gap-2">
            <input
              ref={createInputRef}
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleCreate()
                if (e.key === 'Escape') cancelCreate()
              }}
              placeholder="Notebook title…"
              className="flex-1 rounded-lg border border-primary/60 bg-input px-3 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
            />
            <button
              onClick={handleCreate}
              disabled={!newTitle.trim()}
              className="rounded-lg bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground disabled:opacity-40 hover:opacity-90 transition-opacity"
            >
              Create
            </button>
            <button
              onClick={cancelCreate}
              aria-label="Cancel"
              className="rounded-lg border border-border p-1.5 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Content */}
      <main className="flex-1 px-6 py-6">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl border border-border bg-card text-muted-foreground">
              <FileText className="h-8 w-8" />
            </div>
            {search ? (
              <>
                <p className="text-sm font-medium text-foreground">No notebooks found</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  No results for &ldquo;{search}&rdquo;
                </p>
                <button
                  onClick={() => setSearch('')}
                  className="mt-3 text-xs text-primary hover:underline"
                >
                  Clear search
                </button>
              </>
            ) : (
              <>
                <p className="text-sm font-medium text-foreground">No notebooks yet</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Create your first notebook to get started
                </p>
                <button
                  onClick={openCreateForm}
                  className="mt-4 flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 transition-opacity"
                >
                  <Plus className="h-4 w-4" />
                  New Notebook
                </button>
              </>
            )}
          </div>
        ) : (
          <>
            {search && (
              <p className="mb-4 text-xs text-muted-foreground">
                {filtered.length} result{filtered.length !== 1 ? 's' : ''} for &ldquo;{search}&rdquo;
              </p>
            )}
            <div
              className={
                layout === 'grid'
                  ? 'grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
                  : 'flex flex-col gap-2'
              }
            >
              {filtered.map((note) => (
                <NoteCard
                  key={note.id}
                  note={note}
                  layout={layout}
                  onClick={() => router.push(`/note/${note.id}`)}
                />
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  )
}
