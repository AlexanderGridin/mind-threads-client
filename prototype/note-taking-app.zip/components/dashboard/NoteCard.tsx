'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { BookOpen, Check, Pencil, Trash2, X } from 'lucide-react'
import { useNotes } from '@/components/providers/NotesProvider'
import type { Note } from '@/lib/types'

// ---------------------------------------------------------------------------
// SectionsTooltip — rendered into document.body via a portal so it is never
// clipped by a parent's overflow:hidden.
// ---------------------------------------------------------------------------
interface SectionsTooltipProps {
  note: Note
}

function SectionsTooltip({ note }: SectionsTooltipProps) {
  const [open, setOpen] = useState(false)
  const [coords, setCoords] = useState({ top: 0, left: 0, above: true })
  const triggerRef = useRef<HTMLSpanElement>(null)
  const tooltipRef = useRef<HTMLDivElement>(null)
  const hideTimeout = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [mounted, setMounted] = useState(false)

  useEffect(() => { setMounted(true) }, [])

  const show = () => {
    if (hideTimeout.current) clearTimeout(hideTimeout.current)
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect()
      const spaceAbove = rect.top
      const spaceBelow = window.innerHeight - rect.bottom
      const above = spaceAbove >= 240 || spaceAbove > spaceBelow
      setCoords({
        top: above
          ? rect.top + window.scrollY - 8   // anchor bottom of tooltip to top of trigger; tooltip uses translateY(-100%)
          : rect.bottom + window.scrollY + 8,
        left: rect.left + window.scrollX,
        above,
      })
    }
    setOpen(true)
  }

  const hide = () => {
    hideTimeout.current = setTimeout(() => setOpen(false), 80)
  }

  return (
    <span
      ref={triggerRef}
      className="relative flex items-center gap-1 cursor-default"
      onMouseEnter={show}
      onMouseLeave={hide}
      onFocus={show}
      onBlur={hide}
    >
      <BookOpen className="h-3 w-3" />
      <span>
        {note.sections.length} {note.sections.length === 1 ? 'section' : 'sections'}
      </span>

      {mounted && open && note.sections.length > 0 && createPortal(
        <div
          ref={tooltipRef}
          role="tooltip"
          onMouseEnter={show}
          onMouseLeave={hide}
          style={{
            position: 'absolute',
            top: coords.top,
            left: coords.left,
            zIndex: 9999,
            transform: coords.above ? 'translateY(-100%)' : 'translateY(0)',
          }}
          className="w-48 rounded-lg border border-border bg-popover shadow-lg shadow-background/60"
        >
          {/* arrow — points toward the trigger */}
          <div
            className={`absolute left-3 h-3 w-3 rotate-45 rounded-sm border-border bg-popover ${
              coords.above
                ? '-bottom-1.5 border-b border-r'
                : '-top-1.5 border-t border-l'
            }`}
          />

          <p className="border-b border-border px-3 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Sections
          </p>

          <ul className="max-h-40 overflow-y-auto py-1">
            {note.sections.map((s) => (
              <li
                key={s.id}
                className="flex items-center gap-2 px-3 py-1.5 text-xs text-foreground"
              >
                <span
                  className="h-1.5 w-1.5 shrink-0 rounded-full"
                  style={{ backgroundColor: note.color }}
                />
                <span className="truncate">{s.title}</span>
              </li>
            ))}
          </ul>
        </div>,
        document.body
      )}
    </span>
  )
}

interface NoteCardProps {
  note: Note
  layout?: 'grid' | 'list'
  onClick: () => void
}

function formatRelative(iso: string) {
  const diff = Date.now() - new Date(iso).getTime()
  const min = 60_000
  const hr = 3_600_000
  const day = 86_400_000
  if (diff < min) return 'just now'
  if (diff < hr) return `${Math.floor(diff / min)}m ago`
  if (diff < day) return `${Math.floor(diff / hr)}h ago`
  if (diff < 7 * day) return `${Math.floor(diff / day)}d ago`
  return new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
}

function countEntries(note: Note) {
  return note.sections.reduce(
    (a, s) => a + s.pages.reduce((b, p) => b + p.entries.length, 0),
    0
  )
}

export function NoteCard({ note, layout = 'grid', onClick }: NoteCardProps) {
  const { renameNote, deleteNote } = useNotes()
  const [isEditing, setIsEditing] = useState(false)
  const [editTitle, setEditTitle] = useState(note.title)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const startEdit = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation()
      setEditTitle(note.title)
      setIsEditing(true)
      setTimeout(() => inputRef.current?.select(), 0)
    },
    [note.title]
  )

  const saveEdit = useCallback(() => {
    const trimmed = editTitle.trim()
    if (trimmed && trimmed !== note.title) renameNote(note.id, trimmed)
    setIsEditing(false)
  }, [editTitle, note.id, note.title, renameNote])

  const cancelEdit = useCallback(() => {
    setEditTitle(note.title)
    setIsEditing(false)
  }, [note.title])

  const handleDelete = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation()
      if (showDeleteConfirm) {
        deleteNote(note.id)
      } else {
        setShowDeleteConfirm(true)
        setTimeout(() => setShowDeleteConfirm(false), 3000)
      }
    },
    [deleteNote, note.id, showDeleteConfirm]
  )

  const entryCount = countEntries(note)

  // Shared inline edit input used by both layouts
  const editInput = (
    <div
      className="flex flex-1 items-center gap-1"
      onClick={(e) => e.stopPropagation()}
    >
      <input
        ref={inputRef}
        value={editTitle}
        onChange={(e) => setEditTitle(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') saveEdit()
          if (e.key === 'Escape') cancelEdit()
        }}
        onBlur={saveEdit}
        className="flex-1 rounded-md border border-primary/60 bg-input px-2 py-0.5 text-sm font-semibold text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
      />
      <button
        onMouseDown={(e) => { e.preventDefault(); saveEdit() }}
        aria-label="Save"
        className="text-success hover:opacity-80"
      >
        <Check className="h-3.5 w-3.5" />
      </button>
      <button
        onMouseDown={(e) => { e.preventDefault(); cancelEdit() }}
        aria-label="Cancel"
        className="text-muted-foreground hover:text-foreground"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  )

  // Shared action buttons
  const actions = !isEditing && (
    <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
      <button
        onClick={startEdit}
        aria-label="Rename note"
        className="rounded p-1 text-muted-foreground hover:bg-surface hover:text-foreground transition-colors"
      >
        <Pencil className="h-3 w-3" />
      </button>
      <button
        onClick={handleDelete}
        aria-label={showDeleteConfirm ? 'Confirm delete' : 'Delete note'}
        className={`rounded p-1 transition-colors ${
          showDeleteConfirm
            ? 'bg-destructive/20 text-destructive'
            : 'text-muted-foreground hover:bg-destructive/10 hover:text-destructive'
        }`}
      >
        <Trash2 className="h-3 w-3" />
      </button>
    </div>
  )

  if (layout === 'list') {
    return (
      <article
        onClick={isEditing ? undefined : onClick}
        className="group flex items-center gap-3 overflow-hidden rounded-lg border border-border bg-card px-4 py-3 transition-all duration-200 hover:border-primary/40 hover:shadow-md hover:shadow-background/50 cursor-pointer"
      >
        {/* Color dot */}
        <div
          className="h-2.5 w-2.5 shrink-0 rounded-full"
          style={{ backgroundColor: note.color }}
        />

        {/* Title */}
        <div className="flex min-w-0 flex-1 items-center gap-2">
          {isEditing ? editInput : (
            <h3 className="truncate text-sm font-semibold text-foreground">
              {note.title}
            </h3>
          )}
        </div>

        {/* Meta */}
        <div className="hidden md:flex shrink-0 items-center gap-3 text-xs text-muted-foreground">
          <SectionsTooltip note={note} />
          <span>{entryCount} {entryCount === 1 ? 'entry' : 'entries'}</span>
        </div>

        <time dateTime={note.updatedAt} className="shrink-0 text-xs text-muted-foreground">
          {formatRelative(note.updatedAt)}
        </time>

        {actions}
      </article>
    )
  }

  return (
    <article
      onClick={isEditing ? undefined : onClick}
      className="group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-all duration-200 hover:border-primary/40 hover:shadow-lg hover:shadow-background/50 cursor-pointer"
    >
      {/* Color accent strip */}
      <div
        className="h-1 w-full flex-shrink-0"
        style={{ backgroundColor: note.color }}
      />

      <div className="flex flex-1 flex-col gap-3 p-4">
        {/* Title row */}
        <div className="flex items-start justify-between gap-2">
          {isEditing ? editInput : (
            <h3
              className="flex-1 text-sm font-semibold leading-snug text-foreground text-balance"
              style={{ wordBreak: 'break-word' }}
            >
              {note.title}
            </h3>
          )}
          {actions}
        </div>

        {/* Meta */}
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-3">
            <SectionsTooltip note={note} />
            <span>{entryCount} {entryCount === 1 ? 'entry' : 'entries'}</span>
          </div>
          <time dateTime={note.updatedAt} className="shrink-0">
            {formatRelative(note.updatedAt)}
          </time>
        </div>
      </div>
    </article>
  )
}
