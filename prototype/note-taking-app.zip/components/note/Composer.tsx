'use client'

import { useCallback, useRef, useState } from 'react'
import {
  Bold,
  Code,
  Image,
  Italic,
  Link,
  List,
  ListOrdered,
  Send,
  Strikethrough,
  Tag,
  Underline,
  X,
} from 'lucide-react'

interface ComposerProps {
  onSubmit: (content: string, tags: string[]) => void
  accentColor?: string
}

interface ToolbarButton {
  icon: React.ReactNode
  label: string
  action: () => void
  shortcut?: string
}

export function Composer({ onSubmit, accentColor = '#88c0d0' }: ComposerProps) {
  const editorRef = useRef<HTMLDivElement>(null)
  const [tags, setTags] = useState<string[]>([])
  const [tagInput, setTagInput] = useState('')
  const [showTagInput, setShowTagInput] = useState(false)
  const [isFocused, setIsFocused] = useState(false)

  const exec = useCallback((command: string, value?: string) => {
    editorRef.current?.focus()
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    document.execCommand(command, false, value)
  }, [])

  const insertHTML = useCallback((html: string) => {
    editorRef.current?.focus()
    document.execCommand('insertHTML', false, html)
  }, [])

  const insertCodeBlock = useCallback(() => {
    insertHTML(
      '<pre><code class="language-plaintext">// Enter code here</code></pre><p><br></p>'
    )
  }, [insertHTML])

  const insertLink = useCallback(() => {
    const url = window.prompt('Enter URL:')
    if (url) {
      const text = window.getSelection()?.toString() || url
      insertHTML(`<a href="${url}" target="_blank" rel="noopener">${text}</a>`)
    }
  }, [insertHTML])

  const insertImagePlaceholder = useCallback(() => {
    const fileInput = document.createElement('input')
    fileInput.type = 'file'
    fileInput.accept = 'image/*'
    fileInput.onchange = () => {
      const file = fileInput.files?.[0]
      if (!file) return
      const reader = new FileReader()
      reader.onload = (e) => {
        const src = e.target?.result as string
        insertHTML(
          `<img src="${src}" alt="${file.name}" style="max-width:100%;max-height:320px;border-radius:6px;margin:4px 0;" /><p><br></p>`
        )
      }
      reader.readAsDataURL(file)
    }
    fileInput.click()
  }, [insertHTML])

  const handleSubmit = useCallback(() => {
    const content = editorRef.current?.innerHTML?.trim()
    if (!content || content === '<br>' || content === '<p><br></p>') return
    onSubmit(content, tags)
    if (editorRef.current) {
      editorRef.current.innerHTML = ''
    }
    setTags([])
    setTagInput('')
    setShowTagInput(false)
  }, [onSubmit, tags])

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      // Ctrl/Cmd + Enter to submit
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault()
        handleSubmit()
        return
      }
    },
    [handleSubmit]
  )

  const addTag = useCallback(() => {
    const tag = tagInput.trim().toLowerCase().replace(/\s+/g, '-')
    if (tag && !tags.includes(tag)) {
      setTags((prev) => [...prev, tag])
    }
    setTagInput('')
  }, [tagInput, tags])

  const removeTag = useCallback((tag: string) => {
    setTags((prev) => prev.filter((t) => t !== tag))
  }, [])

  const toolbarButtons: ToolbarButton[] = [
    { icon: <Bold className="h-3.5 w-3.5" />, label: 'Bold', action: () => exec('bold'), shortcut: 'Ctrl+B' },
    { icon: <Italic className="h-3.5 w-3.5" />, label: 'Italic', action: () => exec('italic'), shortcut: 'Ctrl+I' },
    { icon: <Underline className="h-3.5 w-3.5" />, label: 'Underline', action: () => exec('underline'), shortcut: 'Ctrl+U' },
    { icon: <Strikethrough className="h-3.5 w-3.5" />, label: 'Strikethrough', action: () => exec('strikeThrough') },
  ]

  const structureButtons: ToolbarButton[] = [
    { icon: <List className="h-3.5 w-3.5" />, label: 'Bullet list', action: () => exec('insertUnorderedList') },
    { icon: <ListOrdered className="h-3.5 w-3.5" />, label: 'Numbered list', action: () => exec('insertOrderedList') },
    { icon: <Link className="h-3.5 w-3.5" />, label: 'Insert link', action: insertLink },
    { icon: <Code className="h-3.5 w-3.5" />, label: 'Code block', action: insertCodeBlock },
    { icon: <Image className="h-3.5 w-3.5" />, label: 'Insert image', action: insertImagePlaceholder },
  ]

  return (
    <div
      className={`flex flex-col rounded-xl border bg-card transition-all duration-200 ${
        isFocused
          ? 'border-primary/50 shadow-md shadow-primary/5'
          : 'border-border'
      }`}
    >
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-0.5 border-b border-border px-2 py-1.5">
        {toolbarButtons.map((btn) => (
          <button
            key={btn.label}
            onMouseDown={(e) => {
              e.preventDefault() // prevent losing editor focus
              btn.action()
            }}
            title={btn.shortcut ? `${btn.label} (${btn.shortcut})` : btn.label}
            aria-label={btn.label}
            className="rounded p-1.5 text-muted-foreground hover:bg-surface hover:text-foreground transition-colors"
          >
            {btn.icon}
          </button>
        ))}
        <div className="mx-1 h-4 w-px bg-border" aria-hidden />
        {structureButtons.map((btn) => (
          <button
            key={btn.label}
            onMouseDown={(e) => {
              e.preventDefault()
              btn.action()
            }}
            title={btn.label}
            aria-label={btn.label}
            className="rounded p-1.5 text-muted-foreground hover:bg-surface hover:text-foreground transition-colors"
          >
            {btn.icon}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-1">
          <button
            onMouseDown={(e) => {
              e.preventDefault()
              setShowTagInput((v) => !v)
            }}
            title="Add tags"
            aria-label="Add tags"
            className={`rounded p-1.5 transition-colors ${
              showTagInput || tags.length > 0
                ? 'text-primary'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Tag className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Tags row */}
      {(showTagInput || tags.length > 0) && (
        <div className="flex flex-wrap items-center gap-1.5 border-b border-border px-3 py-2">
          {tags.map((tag) => (
            <span
              key={tag}
              className="flex items-center gap-1 rounded-full px-2 py-0.5 text-xs"
              style={{
                backgroundColor: `${accentColor}1a`,
                color: accentColor,
                border: `1px solid ${accentColor}33`,
              }}
            >
              {tag}
              <button
                onClick={() => removeTag(tag)}
                aria-label={`Remove tag ${tag}`}
                className="hover:opacity-70"
              >
                <X className="h-2.5 w-2.5" />
              </button>
            </span>
          ))}
          {showTagInput && (
            <input
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ',') {
                  e.preventDefault()
                  addTag()
                }
                if (e.key === 'Escape') {
                  setShowTagInput(false)
                  setTagInput('')
                }
              }}
              onBlur={addTag}
              placeholder="tag name, Enter to add…"
              className="rounded-full border border-border bg-input px-2 py-0.5 text-xs text-foreground placeholder:text-muted-foreground focus:border-primary/60 focus:outline-none w-36 min-w-0"
            />
          )}
        </div>
      )}

      {/* Editor area */}
      <div
        ref={editorRef}
        contentEditable
        suppressContentEditableWarning
        data-placeholder="Write a note… (Ctrl+Enter to send)"
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        onKeyDown={handleKeyDown}
        className="composer-editor feed-content px-3 py-3 text-sm text-foreground max-h-64 overflow-y-auto"
      />

      {/* Footer / Send */}
      <div className="flex items-center justify-between border-t border-border px-3 py-2">
        <p className="text-[10px] text-muted-foreground">
          <kbd className="rounded border border-border bg-surface px-1 py-0.5 text-[10px] font-mono">Ctrl</kbd>
          {' + '}
          <kbd className="rounded border border-border bg-surface px-1 py-0.5 text-[10px] font-mono">Enter</kbd>
          {' to send'}
        </p>
        <button
          onClick={handleSubmit}
          aria-label="Send entry"
          className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-all"
          style={{
            backgroundColor: accentColor,
            color: '#2e3440',
          }}
          onMouseEnter={(e) => (e.currentTarget.style.opacity = '0.88')}
          onMouseLeave={(e) => (e.currentTarget.style.opacity = '1')}
        >
          <Send className="h-3.5 w-3.5" />
          Add Entry
        </button>
      </div>
    </div>
  )
}
