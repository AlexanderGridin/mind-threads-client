'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Check, Clock, Pencil, Tag, Trash2, X } from 'lucide-react'
import hljs from 'highlight.js/lib/common'
import type { FeedEntry as FeedEntryType } from '@/lib/types'

interface FeedEntryProps {
  entry: FeedEntryType
  accentColor?: string
  onUpdate: (content: string, tags: string[]) => void
  onDelete: () => void
}

function formatDateTime(iso: string) {
  const d = new Date(iso)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  const min = 60_000
  const hr = 3_600_000
  const day = 86_400_000

  let relLabel: string
  if (diff < min) relLabel = 'just now'
  else if (diff < hr) relLabel = `${Math.floor(diff / min)}m ago`
  else if (diff < day) relLabel = `${Math.floor(diff / hr)}h ago`
  else relLabel = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })

  const time = d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })
  return { relLabel, time, full: d.toLocaleString() }
}

export function FeedEntry({ entry, accentColor = '#88c0d0', onUpdate, onDelete }: FeedEntryProps) {
  const contentRef = useRef<HTMLDivElement>(null)
  const editorRef = useRef<HTMLDivElement>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [editTags, setEditTags] = useState<string[]>(entry.tags)
  const [tagInput, setTagInput] = useState('')
  const dt = formatDateTime(entry.createdAt)

  // Apply syntax highlighting to rendered content
  useEffect(() => {
    if (!isEditing && contentRef.current) {
      contentRef.current.querySelectorAll('pre code').forEach((block) => {
        if (!(block as HTMLElement).dataset.highlighted) {
          hljs.highlightElement(block as HTMLElement)
        }
      })
    }
  }, [isEditing, entry.content])

  const startEdit = useCallback(() => {
    setEditTags([...entry.tags])
    setIsEditing(true)
    // Populate editor with current HTML after render
    setTimeout(() => {
      if (editorRef.current) {
        editorRef.current.innerHTML = entry.content
        editorRef.current.focus()
        // Place cursor at end
        const range = document.createRange()
        range.selectNodeContents(editorRef.current)
        range.collapse(false)
        window.getSelection()?.removeAllRanges()
        window.getSelection()?.addRange(range)
      }
    }, 0)
  }, [entry.content, entry.tags])

  const saveEdit = useCallback(() => {
    const content = editorRef.current?.innerHTML || ''
    onUpdate(content, editTags)
    setIsEditing(false)
  }, [editTags, onUpdate])

  const cancelEdit = useCallback(() => {
    setIsEditing(false)
    setEditTags([...entry.tags])
  }, [entry.tags])

  const handleDelete = useCallback(() => {
    if (confirmDelete) {
      onDelete()
    } else {
      setConfirmDelete(true)
      setTimeout(() => setConfirmDelete(false), 3000)
    }
  }, [confirmDelete, onDelete])

  const addTag = useCallback(() => {
    const tag = tagInput.trim().toLowerCase().replace(/\s+/g, '-')
    if (tag && !editTags.includes(tag)) {
      setEditTags((prev) => [...prev, tag])
    }
    setTagInput('')
  }, [tagInput, editTags])

  const removeTag = useCallback((tag: string) => {
    setEditTags((prev) => prev.filter((t) => t !== tag))
  }, [])

  return (
    <article className="group relative flex flex-col gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-border/80">
      {/* Header row */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Clock className="h-3 w-3 shrink-0" />
          <time dateTime={entry.createdAt} title={dt.full}>
            {dt.relLabel} &middot; {dt.time}
          </time>
          {entry.updatedAt !== entry.createdAt && (
            <span className="text-[10px] italic">(edited)</span>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
          {!isEditing && (
            <>
              <button
                onClick={startEdit}
                aria-label="Edit entry"
                className="rounded p-1.5 text-muted-foreground hover:bg-surface hover:text-foreground transition-colors"
              >
                <Pencil className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={handleDelete}
                aria-label={confirmDelete ? 'Confirm delete' : 'Delete entry'}
                className={`rounded p-1.5 transition-colors ${
                  confirmDelete
                    ? 'bg-destructive/15 text-destructive'
                    : 'text-muted-foreground hover:bg-destructive/10 hover:text-destructive'
                }`}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </>
          )}
          {isEditing && (
            <>
              <button
                onClick={saveEdit}
                aria-label="Save"
                className="flex items-center gap-1 rounded px-2 py-1 text-xs font-medium text-success hover:bg-success/10 transition-colors"
              >
                <Check className="h-3.5 w-3.5" />
                Save
              </button>
              <button
                onClick={cancelEdit}
                aria-label="Cancel edit"
                className="rounded p-1.5 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Content */}
      {isEditing ? (
        <div
          ref={editorRef}
          contentEditable
          suppressContentEditableWarning
          data-placeholder="Write your note…"
          className="composer-editor feed-content min-h-[4rem] rounded-lg border border-primary/40 bg-background p-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30"
        />
      ) : (
        <div
          ref={contentRef}
          className="feed-content text-sm text-foreground"
          dangerouslySetInnerHTML={{ __html: entry.content }}
        />
      )}

      {/* Tags */}
      {(entry.tags.length > 0 || isEditing) && (
        <div className="flex flex-wrap items-center gap-1.5">
          <Tag className="h-3 w-3 shrink-0 text-muted-foreground" />
          {isEditing ? (
            <>
              {editTags.map((tag) => (
                <span
                  key={tag}
                  className="flex items-center gap-1 rounded-full px-2 py-0.5 text-xs"
                  style={{
                    backgroundColor: `${accentColor}1a`,
                    color: accentColor,
                    border: `1px solid ${accentColor}33`,
                  }}
                >
                  {tag}
                  <button onClick={() => removeTag(tag)} aria-label={`Remove tag ${tag}`}>
                    <X className="h-2.5 w-2.5" />
                  </button>
                </span>
              ))}
              <input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ',') {
                    e.preventDefault()
                    addTag()
                  }
                }}
                onBlur={addTag}
                placeholder="Add tag…"
                className="rounded-full border border-border bg-input px-2 py-0.5 text-xs text-foreground placeholder:text-muted-foreground focus:border-primary/60 focus:outline-none w-20"
              />
            </>
          ) : (
            entry.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full px-2 py-0.5 text-xs"
                style={{
                  backgroundColor: `${accentColor}1a`,
                  color: accentColor,
                  border: `1px solid ${accentColor}33`,
                }}
              >
                #{tag}
              </span>
            ))
          )}
        </div>
      )}
    </article>
  )
}
