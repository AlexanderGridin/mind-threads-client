'use client'

import { useCallback, useRef, useState } from 'react'
import { Check, Pencil, Plus, Trash2, X } from 'lucide-react'
import { SearchInput } from '@/components/ui/SearchInput'

interface SidebarItem {
  id: string
  title: string
  createdAt: string
  count?: number // sub-item count badge
}

interface SidebarColumnProps {
  title: string
  items: SidebarItem[]
  selectedId: string | null
  onSelect: (id: string) => void
  onAdd: (title: string) => void
  onRename: (id: string, title: string) => void
  onDelete: (id: string) => void
  accentColor?: string
  emptyMessage?: string
  addPlaceholder?: string
}

export function SidebarColumn({
  title,
  items,
  selectedId,
  onSelect,
  onAdd,
  onRename,
  onDelete,
  accentColor = '#88c0d0',
  emptyMessage = 'Nothing here yet',
  addPlaceholder = 'Title…',
}: SidebarColumnProps) {
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [addValue, setAddValue] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editValue, setEditValue] = useState('')
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null)
  const addInputRef = useRef<HTMLInputElement>(null)
  const editInputRef = useRef<HTMLInputElement>(null)

  const filtered = items.filter((i) =>
    i.title.toLowerCase().includes(search.toLowerCase())
  )

  const openAdd = useCallback(() => {
    setAddValue('')
    setShowAdd(true)
    setTimeout(() => addInputRef.current?.focus(), 0)
  }, [])

  const commitAdd = useCallback(() => {
    const v = addValue.trim()
    if (v) onAdd(v)
    setAddValue('')
    setShowAdd(false)
  }, [addValue, onAdd])

  const startEdit = useCallback((item: SidebarItem) => {
    setEditingId(item.id)
    setEditValue(item.title)
    setTimeout(() => editInputRef.current?.select(), 0)
  }, [])

  const commitEdit = useCallback(() => {
    const v = editValue.trim()
    if (v && editingId) onRename(editingId, v)
    setEditingId(null)
  }, [editValue, editingId, onRename])

  const handleDelete = useCallback(
    (id: string, e: React.MouseEvent) => {
      e.stopPropagation()
      if (confirmDeleteId === id) {
        onDelete(id)
        setConfirmDeleteId(null)
      } else {
        setConfirmDeleteId(id)
        setTimeout(() => setConfirmDeleteId(null), 3000)
      }
    },
    [confirmDeleteId, onDelete]
  )

  return (
    <div className="flex h-full flex-col bg-sidebar border-r border-border">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-border px-3 py-3">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {title}
        </h2>
        <button
          onClick={openAdd}
          aria-label={`Add ${title.toLowerCase()}`}
          className="rounded p-1 text-muted-foreground hover:bg-surface hover:text-foreground transition-colors"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Search */}
      <div className="px-2 py-2">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder={`Filter ${title.toLowerCase()}…`}
        />
      </div>

      {/* Add form */}
      {showAdd && (
        <div className="border-b border-border px-2 pb-2">
          <div className="flex items-center gap-1">
            <input
              ref={addInputRef}
              value={addValue}
              onChange={(e) => setAddValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') commitAdd()
                if (e.key === 'Escape') { setShowAdd(false); setAddValue('') }
              }}
              placeholder={addPlaceholder}
              className="flex-1 min-w-0 rounded-md border border-primary/60 bg-input px-2 py-1 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary/30"
            />
            <button
              onMouseDown={(e) => { e.preventDefault(); commitAdd() }}
              disabled={!addValue.trim()}
              aria-label="Add"
              className="text-success hover:opacity-80 disabled:opacity-40"
            >
              <Check className="h-3.5 w-3.5" />
            </button>
            <button
              onMouseDown={(e) => { e.preventDefault(); setShowAdd(false); setAddValue('') }}
              aria-label="Cancel"
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Items */}
      <div className="flex-1 overflow-y-auto py-1">
        {filtered.length === 0 ? (
          <p className="px-3 py-4 text-center text-xs text-muted-foreground">
            {search ? `No results for "${search}"` : emptyMessage}
          </p>
        ) : (
          filtered.map((item) => {
            const isSelected = item.id === selectedId
            const isEditing = editingId === item.id
            const isConfirmDelete = confirmDeleteId === item.id

            return (
              <div
                key={item.id}
                onClick={() => !isEditing && onSelect(item.id)}
                className={`group relative flex min-h-[2.25rem] cursor-pointer items-center gap-2 px-3 py-2 text-sm transition-colors ${
                  isSelected
                    ? 'bg-primary/10 text-foreground'
                    : 'text-foreground/80 hover:bg-surface/60 hover:text-foreground'
                }`}
              >
                {/* Active indicator */}
                {isSelected && (
                  <span
                    className="absolute left-0 top-1/2 -translate-y-1/2 h-5 w-0.5 rounded-r"
                    style={{ backgroundColor: accentColor }}
                  />
                )}

                {isEditing ? (
                  <div
                    className="flex flex-1 items-center gap-1"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <input
                      ref={editInputRef}
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') commitEdit()
                        if (e.key === 'Escape') setEditingId(null)
                      }}
                      onBlur={commitEdit}
                      className="flex-1 min-w-0 rounded border border-primary/60 bg-input px-1.5 py-0.5 text-xs text-foreground focus:outline-none"
                    />
                  </div>
                ) : (
                  <>
                    <span
                      className="flex-1 truncate text-xs leading-snug"
                      title={item.title}
                    >
                      {item.title}
                    </span>
                    {item.count !== undefined && item.count > 0 && (
                      <span className="shrink-0 rounded-full px-1.5 py-0.5 text-[10px] leading-none bg-surface text-muted-foreground">
                        {item.count}
                      </span>
                    )}
                  </>
                )}

                {/* Actions (hover) */}
                {!isEditing && (
                  <div className="absolute right-1 flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity bg-sidebar rounded">
                    <button
                      onClick={(e) => { e.stopPropagation(); startEdit(item) }}
                      aria-label="Rename"
                      className="rounded p-0.5 text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <Pencil className="h-3 w-3" />
                    </button>
                    <button
                      onClick={(e) => handleDelete(item.id, e)}
                      aria-label={isConfirmDelete ? 'Confirm delete' : 'Delete'}
                      className={`rounded p-0.5 transition-colors ${
                        isConfirmDelete
                          ? 'text-destructive'
                          : 'text-muted-foreground hover:text-destructive'
                      }`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                )}
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}
