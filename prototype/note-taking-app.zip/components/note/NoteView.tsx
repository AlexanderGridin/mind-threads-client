'use client'

import { useCallback, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, FileText, Inbox } from 'lucide-react'
import { useNotes } from '@/components/providers/NotesProvider'
import { ThemeToggle } from '@/components/ui/ThemeToggle'
import { SidebarColumn } from './SidebarColumn'
import { FeedEntry } from './FeedEntry'
import { Composer } from './Composer'

interface NoteViewProps {
  noteId: string
}

export function NoteView({ noteId }: NoteViewProps) {
  const router = useRouter()
  const {
    notes,
    createSection,
    renameSection,
    deleteSection,
    createPage,
    renamePage,
    deletePage,
    createEntry,
    updateEntry,
    deleteEntry,
  } = useNotes()

  const note = useMemo(() => notes.find((n) => n.id === noteId), [notes, noteId])

  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(
    () => note?.sections[0]?.id ?? null
  )
  const [selectedPageId, setSelectedPageId] = useState<string | null>(
    () => note?.sections[0]?.pages[0]?.id ?? null
  )

  const selectedSection = useMemo(
    () => note?.sections.find((s) => s.id === selectedSectionId) ?? null,
    [note, selectedSectionId]
  )

  const selectedPage = useMemo(
    () => selectedSection?.pages.find((p) => p.id === selectedPageId) ?? null,
    [selectedSection, selectedPageId]
  )

  const handleSelectSection = useCallback(
    (id: string) => {
      setSelectedSectionId(id)
      const section = note?.sections.find((s) => s.id === id)
      setSelectedPageId(section?.pages[0]?.id ?? null)
    },
    [note]
  )

  const handleAddSection = useCallback(
    (title: string) => {
      const section = createSection(noteId, title)
      setSelectedSectionId(section.id)
      setSelectedPageId(null)
    },
    [createSection, noteId]
  )

  const handleDeleteSection = useCallback(
    (id: string) => {
      deleteSection(noteId, id)
      if (selectedSectionId === id) {
        const remaining = note?.sections.filter((s) => s.id !== id) ?? []
        const next = remaining[0] ?? null
        setSelectedSectionId(next?.id ?? null)
        setSelectedPageId(next?.pages[0]?.id ?? null)
      }
    },
    [deleteSection, noteId, selectedSectionId, note]
  )

  const handleAddPage = useCallback(
    (title: string) => {
      if (!selectedSectionId) return
      const page = createPage(noteId, selectedSectionId, title)
      setSelectedPageId(page.id)
    },
    [createPage, noteId, selectedSectionId]
  )

  const handleDeletePage = useCallback(
    (id: string) => {
      if (!selectedSectionId) return
      deletePage(noteId, selectedSectionId, id)
      if (selectedPageId === id) {
        const remaining = selectedSection?.pages.filter((p) => p.id !== id) ?? []
        setSelectedPageId(remaining[0]?.id ?? null)
      }
    },
    [deletePage, noteId, selectedSectionId, selectedPageId, selectedSection]
  )

  const handleAddEntry = useCallback(
    (content: string, tags: string[]) => {
      if (!selectedSectionId || !selectedPageId) return
      createEntry(noteId, selectedSectionId, selectedPageId, content, tags)
    },
    [createEntry, noteId, selectedSectionId, selectedPageId]
  )

  if (!note) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background">
        <p className="text-sm text-muted-foreground">Notebook not found.</p>
        <button
          onClick={() => router.push('/')}
          className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 transition-opacity"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to notebooks
        </button>
      </div>
    )
  }

  const sectionItems = note.sections.map((s) => ({
    id: s.id,
    title: s.title,
    createdAt: s.createdAt,
    count: s.pages.length,
  }))

  const pageItems = selectedSection
    ? selectedSection.pages.map((p) => ({
        id: p.id,
        title: p.title,
        createdAt: p.createdAt,
        count: p.entries.length,
      }))
    : []

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background">
      {/* Top nav */}
      <header className="flex shrink-0 items-center justify-between border-b border-border bg-background px-4 py-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => router.push('/')}
            aria-label="Back to notebooks"
            className="flex items-center gap-1.5 rounded-lg p-1.5 text-muted-foreground hover:bg-surface hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="flex items-center gap-2">
            <span
              className="h-3 w-3 rounded-full shrink-0"
              style={{ backgroundColor: note.color }}
              aria-hidden
            />
            <h1 className="text-sm font-semibold text-foreground leading-none truncate max-w-[200px] sm:max-w-xs">
              {note.title}
            </h1>
          </div>
          {selectedSection && (
            <>
              <span className="text-muted-foreground/40" aria-hidden>/</span>
              <span className="hidden sm:block text-sm text-muted-foreground truncate max-w-[120px]">
                {selectedSection.title}
              </span>
            </>
          )}
          {selectedPage && (
            <>
              <span className="hidden sm:block text-muted-foreground/40" aria-hidden>/</span>
              <span className="hidden sm:block text-sm text-muted-foreground truncate max-w-[120px]">
                {selectedPage.title}
              </span>
            </>
          )}
        </div>
        <ThemeToggle />
      </header>

      {/* 3-column body */}
      <div className="flex flex-1 overflow-hidden">
        {/* Column 1: Sections */}
        <div className="hidden w-48 shrink-0 md:flex md:flex-col border-r border-border overflow-hidden">
          <SidebarColumn
            title="Sections"
            items={sectionItems}
            selectedId={selectedSectionId}
            onSelect={handleSelectSection}
            onAdd={handleAddSection}
            onRename={(id, title) => renameSection(noteId, id, title)}
            onDelete={handleDeleteSection}
            accentColor={note.color}
            emptyMessage="No sections yet"
            addPlaceholder="Section name…"
          />
        </div>

        {/* Column 2: Pages */}
        <div className="hidden w-44 shrink-0 lg:flex lg:flex-col border-r border-border overflow-hidden">
          {selectedSection ? (
            <SidebarColumn
              title="Pages"
              items={pageItems}
              selectedId={selectedPageId}
              onSelect={setSelectedPageId}
              onAdd={handleAddPage}
              onRename={(id, title) =>
                renamePage(noteId, selectedSectionId!, id, title)
              }
              onDelete={handleDeletePage}
              accentColor={note.color}
              emptyMessage="No pages yet"
              addPlaceholder="Page name…"
            />
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-2 bg-sidebar p-4 text-center">
              <FileText className="h-6 w-6 text-muted-foreground/40" />
              <p className="text-xs text-muted-foreground">Select a section first</p>
            </div>
          )}
        </div>

        {/* Column 3: Feed */}
        <main className="flex flex-1 flex-col overflow-hidden">
          {selectedPage ? (
            <div className="flex flex-1 flex-col overflow-hidden">
              {/* Page header */}
              <div className="flex shrink-0 items-center gap-2 border-b border-border px-5 py-3">
                <h2 className="text-sm font-semibold text-foreground">
                  {selectedPage.title}
                </h2>
                <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">
                  {selectedPage.entries.length}{' '}
                  {selectedPage.entries.length === 1 ? 'entry' : 'entries'}
                </span>
              </div>

              {/* Scrollable feed */}
              <div className="flex-1 overflow-y-auto px-5 py-4">
                {/* Composer pinned at top */}
                <div className="mb-5">
                  <Composer onSubmit={handleAddEntry} accentColor={note.color} />
                </div>

                {/* Entries */}
                {selectedPage.entries.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <Inbox className="mb-3 h-10 w-10 text-muted-foreground/30" />
                    <p className="text-sm text-muted-foreground">No entries yet</p>
                    <p className="mt-1 text-xs text-muted-foreground/60">
                      Write something above to get started
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-3">
                    {selectedPage.entries.map((entry) => (
                      <FeedEntry
                        key={entry.id}
                        entry={entry}
                        accentColor={note.color}
                        onUpdate={(content, tags) =>
                          updateEntry(
                            noteId,
                            selectedSectionId!,
                            selectedPageId!,
                            entry.id,
                            content,
                            tags
                          )
                        }
                        onDelete={() =>
                          deleteEntry(
                            noteId,
                            selectedSectionId!,
                            selectedPageId!,
                            entry.id
                          )
                        }
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center px-6">
              <div
                className="flex h-14 w-14 items-center justify-center rounded-2xl border border-border"
                style={{ backgroundColor: `${note.color}15` }}
              >
                <FileText className="h-7 w-7" style={{ color: note.color }} />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">
                  {note.sections.length === 0
                    ? 'No sections yet'
                    : selectedSection
                    ? 'No pages in this section'
                    : 'Select a section to begin'}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {note.sections.length === 0
                    ? 'Create a section in the left panel'
                    : 'Create a page to start writing'}
                </p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
