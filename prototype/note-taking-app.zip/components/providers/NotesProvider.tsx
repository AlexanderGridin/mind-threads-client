'use client'

import {
  createContext,
  useCallback,
  useContext,
  useState,
} from 'react'
import { MOCK_NOTES } from '@/lib/mock-data'
import type { FeedEntry, Note, NotePage, NoteSection } from '@/lib/types'

interface NotesContextValue {
  notes: Note[]
  // Notes CRUD
  createNote: (title: string) => Note
  renameNote: (id: string, title: string) => void
  deleteNote: (id: string) => void
  // Sections CRUD
  createSection: (noteId: string, title: string) => NoteSection
  renameSection: (noteId: string, sectionId: string, title: string) => void
  deleteSection: (noteId: string, sectionId: string) => void
  // Pages CRUD
  createPage: (noteId: string, sectionId: string, title: string) => NotePage
  renamePage: (noteId: string, sectionId: string, pageId: string, title: string) => void
  deletePage: (noteId: string, sectionId: string, pageId: string) => void
  // Entries CRUD
  createEntry: (noteId: string, sectionId: string, pageId: string, content: string, tags: string[]) => FeedEntry
  updateEntry: (noteId: string, sectionId: string, pageId: string, entryId: string, content: string, tags: string[]) => void
  deleteEntry: (noteId: string, sectionId: string, pageId: string, entryId: string) => void
}

const NotesContext = createContext<NotesContextValue | null>(null)

const uid = () => Math.random().toString(36).slice(2, 10)

export function NotesProvider({ children }: { children: React.ReactNode }) {
  const [notes, setNotes] = useState<Note[]>(() =>
    JSON.parse(JSON.stringify(MOCK_NOTES))
  )

  /* ─── Notes ─────────────────────────────────────────────── */
  const createNote = useCallback((title: string): Note => {
    const note: Note = {
      id: `note-${uid()}`,
      title,
      color: ['#88c0d0', '#a3be8c', '#b48ead', '#ebcb8b', '#d08770'][
        Math.floor(Math.random() * 5)
      ],
      sections: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    setNotes((prev) => [note, ...prev])
    return note
  }, [])

  const renameNote = useCallback((id: string, title: string) => {
    setNotes((prev) =>
      prev.map((n) =>
        n.id === id ? { ...n, title, updatedAt: new Date().toISOString() } : n
      )
    )
  }, [])

  const deleteNote = useCallback((id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id))
  }, [])

  /* ─── Sections ───────────────────────────────────────────── */
  const createSection = useCallback((noteId: string, title: string): NoteSection => {
    const section: NoteSection = {
      id: `sec-${uid()}`,
      title,
      pages: [],
      createdAt: new Date().toISOString(),
    }
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId
          ? { ...n, sections: [...n.sections, section], updatedAt: new Date().toISOString() }
          : n
      )
    )
    return section
  }, [])

  const renameSection = useCallback((noteId: string, sectionId: string, title: string) => {
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId
          ? {
              ...n,
              sections: n.sections.map((s) =>
                s.id === sectionId ? { ...s, title } : s
              ),
            }
          : n
      )
    )
  }, [])

  const deleteSection = useCallback((noteId: string, sectionId: string) => {
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId
          ? { ...n, sections: n.sections.filter((s) => s.id !== sectionId) }
          : n
      )
    )
  }, [])

  /* ─── Pages ──────────────────────────────────────────────── */
  const createPage = useCallback((noteId: string, sectionId: string, title: string): NotePage => {
    const page: NotePage = {
      id: `page-${uid()}`,
      title,
      entries: [],
      createdAt: new Date().toISOString(),
    }
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId
          ? {
              ...n,
              sections: n.sections.map((s) =>
                s.id === sectionId
                  ? { ...s, pages: [...s.pages, page] }
                  : s
              ),
            }
          : n
      )
    )
    return page
  }, [])

  const renamePage = useCallback((noteId: string, sectionId: string, pageId: string, title: string) => {
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId
          ? {
              ...n,
              sections: n.sections.map((s) =>
                s.id === sectionId
                  ? {
                      ...s,
                      pages: s.pages.map((p) =>
                        p.id === pageId ? { ...p, title } : p
                      ),
                    }
                  : s
              ),
            }
          : n
      )
    )
  }, [])

  const deletePage = useCallback((noteId: string, sectionId: string, pageId: string) => {
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId
          ? {
              ...n,
              sections: n.sections.map((s) =>
                s.id === sectionId
                  ? { ...s, pages: s.pages.filter((p) => p.id !== pageId) }
                  : s
              ),
            }
          : n
      )
    )
  }, [])

  /* ─── Entries ────────────────────────────────────────────── */
  const createEntry = useCallback(
    (noteId: string, sectionId: string, pageId: string, content: string, tags: string[]): FeedEntry => {
      const entry: FeedEntry = {
        id: `entry-${uid()}`,
        content,
        tags,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
      setNotes((prev) =>
        prev.map((n) =>
          n.id === noteId
            ? {
                ...n,
                updatedAt: new Date().toISOString(),
                sections: n.sections.map((s) =>
                  s.id === sectionId
                    ? {
                        ...s,
                        pages: s.pages.map((p) =>
                          p.id === pageId
                            ? { ...p, entries: [entry, ...p.entries] }
                            : p
                        ),
                      }
                    : s
                ),
              }
            : n
        )
      )
      return entry
    },
    []
  )

  const updateEntry = useCallback(
    (noteId: string, sectionId: string, pageId: string, entryId: string, content: string, tags: string[]) => {
      setNotes((prev) =>
        prev.map((n) =>
          n.id === noteId
            ? {
                ...n,
                sections: n.sections.map((s) =>
                  s.id === sectionId
                    ? {
                        ...s,
                        pages: s.pages.map((p) =>
                          p.id === pageId
                            ? {
                                ...p,
                                entries: p.entries.map((e) =>
                                  e.id === entryId
                                    ? { ...e, content, tags, updatedAt: new Date().toISOString() }
                                    : e
                                ),
                              }
                            : p
                        ),
                      }
                    : s
                ),
              }
            : n
        )
      )
    },
    []
  )

  const deleteEntry = useCallback(
    (noteId: string, sectionId: string, pageId: string, entryId: string) => {
      setNotes((prev) =>
        prev.map((n) =>
          n.id === noteId
            ? {
                ...n,
                sections: n.sections.map((s) =>
                  s.id === sectionId
                    ? {
                        ...s,
                        pages: s.pages.map((p) =>
                          p.id === pageId
                            ? { ...p, entries: p.entries.filter((e) => e.id !== entryId) }
                            : p
                        ),
                      }
                    : s
                ),
              }
            : n
        )
      )
    },
    []
  )

  return (
    <NotesContext.Provider
      value={{
        notes,
        createNote,
        renameNote,
        deleteNote,
        createSection,
        renameSection,
        deleteSection,
        createPage,
        renamePage,
        deletePage,
        createEntry,
        updateEntry,
        deleteEntry,
      }}
    >
      {children}
    </NotesContext.Provider>
  )
}

export function useNotes() {
  const ctx = useContext(NotesContext)
  if (!ctx) throw new Error('useNotes must be used within NotesProvider')
  return ctx
}
