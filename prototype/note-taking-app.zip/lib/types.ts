export interface FeedEntry {
  id: string
  content: string // HTML string from rich text editor
  tags: string[]
  createdAt: string // ISO date string
  updatedAt: string
}

export interface NotePage {
  id: string
  title: string
  entries: FeedEntry[]
  createdAt: string
}

export interface NoteSection {
  id: string
  title: string
  pages: NotePage[]
  createdAt: string
}

export interface Note {
  id: string
  title: string
  color: string // hex accent color
  sections: NoteSection[]
  createdAt: string
  updatedAt: string
}
