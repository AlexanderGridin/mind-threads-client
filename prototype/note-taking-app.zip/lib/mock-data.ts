import { Note } from './types'

// Fixed epoch so server and client produce identical timestamps (no hydration mismatch).
const EPOCH = new Date('2026-06-22T12:00:00.000Z').getTime()

const t = (offsetMs: number) =>
  new Date(EPOCH - offsetMs).toISOString()

const min = 60_000
const hr = 3_600_000
const day = 86_400_000

export const MOCK_NOTES: Note[] = [
  {
    id: 'note-1',
    title: 'Work Projects',
    color: '#88c0d0',
    createdAt: t(14 * day),
    updatedAt: t(2 * hr),
    sections: [
      {
        id: 'sec-1-1',
        title: 'Q3 Roadmap',
        createdAt: t(14 * day),
        pages: [
          {
            id: 'page-1-1-1',
            title: 'Backend Tasks',
            createdAt: t(10 * day),
            entries: [
              {
                id: 'entry-1',
                tags: ['auth', 'api'],
                createdAt: t(2 * hr),
                updatedAt: t(2 * hr),
                content: `<p>Implemented JWT middleware for the <strong>auth service</strong>. Token expiry set to 15 minutes with refresh rotation.</p>
<pre><code class="language-typescript">export const authMiddleware = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ error: 'Unauthorized' })
  const payload = jwt.verify(token, process.env.JWT_SECRET!)
  req.user = payload
  next()
}</code></pre>`,
              },
              {
                id: 'entry-2',
                tags: ['rate-limiting', 'redis'],
                createdAt: t(6 * hr),
                updatedAt: t(6 * hr),
                content: `<p>Fixed API rate limiting — was hitting <em>false positives</em> on burst traffic. Updated strategy:</p>
<ul>
  <li>Window: sliding 60s instead of fixed</li>
  <li>Limit: 200 req/min per user, 1000 req/min per IP</li>
  <li>Storage: Redis with TTL auto-expiry</li>
</ul>
<p>Need to revisit the <strong>webhook endpoints</strong> — they currently bypass rate limiting entirely.</p>`,
              },
              {
                id: 'entry-3',
                tags: ['db', 'migration'],
                createdAt: t(1 * day),
                updatedAt: t(1 * day),
                content: `<p>Ran the schema migration on staging. Added <code>user_preferences</code> table with JSONB column for flexible settings storage.</p>
<p>Rollback plan is documented in <strong>Notion under Incident Runbooks</strong>.</p>`,
              },
            ],
          },
          {
            id: 'page-1-1-2',
            title: 'Frontend Tasks',
            createdAt: t(9 * day),
            entries: [
              {
                id: 'entry-4',
                tags: ['ui', 'dashboard'],
                createdAt: t(3 * hr),
                updatedAt: t(3 * hr),
                content: `<p>Redesigned the <strong>analytics dashboard</strong>. Moved from recharts to a custom canvas renderer — reduced bundle size by <em>~42kb</em>.</p>
<p>New charts render in under 16ms even with 10k data points.</p>`,
              },
              {
                id: 'entry-5',
                tags: ['performance'],
                createdAt: t(8 * hr),
                updatedAt: t(8 * hr),
                content: `<p>Lighthouse scores after optimization:</p>
<ul>
  <li><strong>Performance:</strong> 94 → 99</li>
  <li><strong>Accessibility:</strong> 88 → 96</li>
  <li><strong>Best Practices:</strong> 92 → 100</li>
  <li><strong>SEO:</strong> 100</li>
</ul>`,
              },
            ],
          },
        ],
      },
      {
        id: 'sec-1-2',
        title: 'Team Standup',
        createdAt: t(7 * day),
        pages: [
          {
            id: 'page-1-2-1',
            title: 'Week of June 16',
            createdAt: t(6 * day),
            entries: [
              {
                id: 'entry-6',
                tags: ['standup', 'blocker'],
                createdAt: t(1 * hr),
                updatedAt: t(1 * hr),
                content: `<p><strong>Blockers:</strong> Waiting on design sign-off for the new onboarding flow.</p>
<p><strong>Done:</strong></p>
<ol>
  <li>Completed API contract review with mobile team</li>
  <li>Fixed prod bug with notification batching (#1247)</li>
  <li>Deployed config service to staging</li>
</ol>
<p><strong>Next:</strong> Start implementation of offline sync feature.</p>`,
              },
            ],
          },
          {
            id: 'page-1-2-2',
            title: 'Week of June 9',
            createdAt: t(13 * day),
            entries: [
              {
                id: 'entry-7',
                tags: ['standup'],
                createdAt: t(7 * day),
                updatedAt: t(7 * day),
                content: `<p>Sprint retrospective notes — team velocity improved by <em>18%</em> after removing the daily sync meetings.</p>`,
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 'note-2',
    title: 'Personal Journal',
    color: '#a3be8c',
    createdAt: t(30 * day),
    updatedAt: t(5 * hr),
    sections: [
      {
        id: 'sec-2-1',
        title: 'Goals & Reviews',
        createdAt: t(30 * day),
        pages: [
          {
            id: 'page-2-1-1',
            title: '2024 Goals',
            createdAt: t(25 * day),
            entries: [
              {
                id: 'entry-8',
                tags: ['goals', 'health'],
                createdAt: t(5 * hr),
                updatedAt: t(5 * hr),
                content: `<p>Mid-year check-in on goals. <strong>Tracking well</strong> overall.</p>
<ul>
  <li>✓ Read 24 books — currently at 14</li>
  <li>✓ Exercise 4x/week — averaging 3.8x</li>
  <li>~ Launch side project — 60% complete</li>
  <li>✗ Learn Spanish — need to restart</li>
</ul>`,
              },
              {
                id: 'entry-9',
                tags: ['reflection'],
                createdAt: t(15 * day),
                updatedAt: t(15 * day),
                content: `<p>The biggest insight from the first half of the year: <em>saying no more often opens space for the things that actually matter.</em></p>`,
              },
            ],
          },
          {
            id: 'page-2-1-2',
            title: 'Monthly Review — June',
            createdAt: t(5 * day),
            entries: [
              {
                id: 'entry-10',
                tags: ['review', 'june'],
                createdAt: t(5 * day),
                updatedAt: t(5 * day),
                content: `<p>June was a <strong>high-output month</strong>. Shipped 3 major features, finished <em>Thinking, Fast and Slow</em>, and started running again.</p>`,
              },
            ],
          },
        ],
      },
      {
        id: 'sec-2-2',
        title: 'Ideas & Inspiration',
        createdAt: t(20 * day),
        pages: [
          {
            id: 'page-2-2-1',
            title: 'App Ideas',
            createdAt: t(18 * day),
            entries: [
              {
                id: 'entry-11',
                tags: ['idea', 'saas'],
                createdAt: t(12 * hr),
                updatedAt: t(12 * hr),
                content: `<p>Ideas worth exploring:</p>
<ol>
  <li><strong>AI contract reviewer</strong> — paste contract, get plain-English summary + risk flags</li>
  <li><strong>Focus timer with ambient sounds</strong> — pairs Pomodoro with procedurally generated soundscapes</li>
  <li><strong>Meal plan optimizer</strong> — input dietary constraints, budget, generates a week of recipes</li>
</ol>`,
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 'note-3',
    title: 'Research Notes',
    color: '#b48ead',
    createdAt: t(45 * day),
    updatedAt: t(1 * day),
    sections: [
      {
        id: 'sec-3-1',
        title: 'AI & ML Papers',
        createdAt: t(45 * day),
        pages: [
          {
            id: 'page-3-1-1',
            title: 'Transformers',
            createdAt: t(40 * day),
            entries: [
              {
                id: 'entry-12',
                tags: ['attention', 'paper'],
                createdAt: t(1 * day),
                updatedAt: t(1 * day),
                content: `<p><strong>"Attention Is All You Need"</strong> — key insight: replace recurrence with self-attention. Enables full parallelization over sequence length.</p>
<pre><code class="language-python">def attention(Q, K, V, d_k):
    scores = (Q @ K.T) / math.sqrt(d_k)
    weights = softmax(scores, dim=-1)
    return weights @ V</code></pre>
<p>Multi-head attention allows the model to jointly attend to information from <em>different representation subspaces</em>.</p>`,
              },
            ],
          },
          {
            id: 'page-3-1-2',
            title: 'Diffusion Models',
            createdAt: t(25 * day),
            entries: [
              {
                id: 'entry-13',
                tags: ['generative', 'ddpm'],
                createdAt: t(3 * day),
                updatedAt: t(3 * day),
                content: `<p>DDPMs work by gradually adding Gaussian noise over <em>T</em> timesteps (forward process), then learning the reverse denoising process.</p>
<ul>
  <li>Forward: q(x_t | x_{t-1}) = N(x_t; √(1-β_t) x_{t-1}, β_t I)</li>
  <li>Reverse: learned by a U-Net conditioned on t</li>
</ul>`,
              },
            ],
          },
        ],
      },
      {
        id: 'sec-3-2',
        title: 'TypeScript Deep Dives',
        createdAt: t(20 * day),
        pages: [
          {
            id: 'page-3-2-1',
            title: 'Advanced Generics',
            createdAt: t(10 * day),
            entries: [
              {
                id: 'entry-14',
                tags: ['typescript', 'generics'],
                createdAt: t(4 * day),
                updatedAt: t(4 * day),
                content: `<p>Conditional types + infer for extracting nested types:</p>
<pre><code class="language-typescript">type UnwrapPromise&lt;T&gt; = T extends Promise&lt;infer U&gt; ? U : T

type DeepReadonly&lt;T&gt; = {
  readonly [K in keyof T]: T[K] extends object
    ? DeepReadonly&lt;T[K]&gt;
    : T[K]
}</code></pre>`,
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 'note-4',
    title: 'Design System',
    color: '#ebcb8b',
    createdAt: t(8 * day),
    updatedAt: t(30 * min),
    sections: [
      {
        id: 'sec-4-1',
        title: 'Tokens & Foundations',
        createdAt: t(8 * day),
        pages: [
          {
            id: 'page-4-1-1',
            title: 'Color System',
            createdAt: t(7 * day),
            entries: [
              {
                id: 'entry-15',
                tags: ['colors', 'accessibility'],
                createdAt: t(30 * min),
                updatedAt: t(30 * min),
                content: `<p>Color token conventions for the new design system:</p>
<ul>
  <li><strong>Semantic tokens</strong> over raw values — use <code>text-error</code> not <code>text-red-500</code></li>
  <li>All text/background combos must pass <strong>WCAG AA</strong> (4.5:1)</li>
  <li>Neutral palette: 11 steps from pure white to near-black</li>
</ul>
<p>Decided to ship with <em>light mode first</em>, dark mode in v2.</p>`,
              },
            ],
          },
          {
            id: 'page-4-1-2',
            title: 'Typography Scale',
            createdAt: t(5 * day),
            entries: [
              {
                id: 'entry-16',
                tags: ['typography', 'type-scale'],
                createdAt: t(2 * day),
                updatedAt: t(2 * day),
                content: `<p>Settled on <strong>Inter</strong> for UI text and <strong>Lora</strong> for editorial/marketing content.</p>
<p>Type scale: 12 / 14 / 16 / 20 / 24 / 32 / 40 / 48px — each step is ×1.25 (Major Third).</p>`,
              },
            ],
          },
        ],
      },
    ],
  },
]
